package com.example.tempmeter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class secondpage extends Activity  {
    String list[] =  new String [] {"SQL","JAVA","JAVA SCRIPT","C#","PYTHON","C++","PHP"};
    public static final Integer[] images = { R.drawable.sqlimagee,
            R.drawable.javaimage, R.drawable.js, R.drawable.chimagee, R.drawable.logo, R.drawable.cimagee, R.drawable.phpimage };
    ListView listView;
    List<Rowitem> rowItems;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondpage);

        rowItems = new ArrayList<Rowitem>();
        for (int i = 0; i < list.length; i++) {
            Rowitem item = new Rowitem(images[i], list[i]);
            rowItems.add(item);
        }
        listView = (ListView) findViewById(R.id.list);
        customadapter adapter = new customadapter(this,
                R.layout.itemlistview, rowItems);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                switch(position){
                    case 0:
                        Intent blankpage = new Intent(getApplicationContext(),thirdpage.class);
                        startActivity(blankpage);
                        break;
                    case 1:
                        Intent blankpage1 = new Intent(getApplicationContext(),thirdpage.class);
                        startActivity(blankpage1);
                        break;
                    case 2:
                        Intent blankpage2 = new Intent(getApplicationContext(),thirdpage.class);
                        startActivity(blankpage2);
                        break;
                    case 3:
                        Intent blankpage3 = new Intent(getApplicationContext(),thirdpage.class);
                        startActivity(blankpage3);
                        break;
                    case 4:
                        Intent blankpage4 = new Intent(getApplicationContext(),thirdpage.class);
                        startActivity(blankpage4);
                        break;
                    case 5:
                        Intent blankpage5 = new Intent(getApplicationContext(),thirdpage.class);
                        startActivity(blankpage5);
                        break;
                    case 6:
                        Intent blankpage6 = new Intent(getApplicationContext(),thirdpage.class);
                        startActivity(blankpage6);
                        break;
                }

            }

            })

    ;}
    }









