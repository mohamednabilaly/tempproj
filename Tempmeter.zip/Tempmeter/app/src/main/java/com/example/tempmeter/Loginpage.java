package com.example.tempmeter;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class Loginpage extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private  EditText emailfield;
    private EditText passwordfield;
    private Button signinbtn;
    private Button signupbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firebaseAuth = FirebaseAuth.getInstance();

        final EditText emailfield = (EditText) findViewById(R.id.Emailfield);
        final EditText passwordfield = (EditText) findViewById(R.id.Passwordcfield);

        Button signupb = (Button) findViewById(R.id.Signupbtnn);
        signupb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open2page();
            }
        });

        Button signinbtn = (Button) findViewById(R.id.Signinbtnn);
        signinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email1 = emailfield.getText().toString().trim();
                final String pass1 = passwordfield.getText().toString().trim();

                if(email1.isEmpty()){
                    Toastmasg("Please enter email");
                    return;
                }if(pass1.isEmpty()){
                    Toastmasg("Please enter password");
                    return;
                }
                firebaseAuth.signInWithEmailAndPassword(email1, pass1).addOnCompleteListener(Loginpage.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(!task.isSuccessful()){
                            Toastmasg("try again");
                        }if(pass1.length()<6){
                            passwordfield.setError("Reenter password");
                            passwordfield.requestFocus();
                        }else{
                            openpage();
                        }
                    }
                });
            }
        });

    }



        public void openpage () {
            Intent newpage = new Intent(Loginpage.this, secondpage.class);
            startActivity(newpage);
        }

        public void open2page () {
            Intent newpage2 = new Intent(Loginpage.this, signup.class);
            startActivity(newpage2);
        }

        private void Toastmasg (String msg){
            Toast.makeText(this, msg, Toast.LENGTH_LONG);
        }


}
